import { Dialog, DialogTitle, DialogContent, DialogActions, Button } from '@material-ui/core';
import { supabase } from "../supabaseClient";
import React, { useEffect, useState } from "react";
import QRCode from 'qrcode.react';
import { updateData } from '../function';
import QRCodeSVG from 'qrcode-svg';

export default function QrcodeGeneration() {
    const [nameQrCode, setNameQrCode] = useState('');
    const [open, setOpen] = useState(false);
    const [data, setData] = useState({
        email: null,
        tele: null,
        logo: null,
        names: null,
        NameBusiness: null,
        description: null,
    });

    useEffect(() => {
        const fetchData = async () => {
            const { data: userData } = await supabase.auth.getUser();

            if (userData) {
                let consolidatedData = {};

                const emailResponse = await supabase.from('email').select('*').eq('show', true);
                consolidatedData.email = emailResponse.data?.[0]?.email;

                const teleResponse = await supabase.from('tele').select('*').eq('show', true);
                consolidatedData.tele = teleResponse.data?.[0]?.tele;

                const logoResponse = await supabase.from('logo').select('*').eq('show', true);
                consolidatedData.logo = logoResponse.data?.[0]?.logo;

                const nameResponse = await supabase.from('namesAlias').select('*').eq('show', true);
                consolidatedData.names = nameResponse.data?.[0]?.names;

                const businessResponse = await supabase.from('Business').select('*').eq('show', true);
                consolidatedData.NameBusiness = businessResponse.data?.[0]?.NameBusiness;

                const descriptionResponse = await supabase.from('Business').select('*').eq('show', true);
                consolidatedData.description = descriptionResponse.data?.[0]?.description;

                setData(consolidatedData);
            }
        };
        fetchData();
    }, []);

    const insertQrCode = async (event) => {
        event.preventDefault();
    
        // Generate the QR code value
        const qrCodeValue = constructQRContent();
    
        try {
            // Create a new instance of QRCodeSVG
            const qr = new QRCodeSVG({
                content: qrCodeValue,
                padding: 4,
                width: 400,
                height: 400,
            });
    
            // Get the SVG XML as a string
            const svgString = qr.svg();
    
            // Convert the SVG string to a data URL
            const dataURL = `data:image/svg+xml;base64,${btoa(svgString)}`;
    
            // Proceed with the rest of the code
            const response = await fetch(dataURL);
            const blob = await response.blob();
    
            const { data, error } = await supabase
                .from("QrCode")
                .upsert([{ qr_code_image: blob, nameQrCode }]);
            
            if (error) {
                console.error("Error inserting QR code:", error);
            } else {
                console.log("QR code inserted successfully:", data);
            }
        } catch (error) {
            console.error("Error generating or inserting QR code:", error);
        }
    };
    

    const constructQRContent = () => {
        let content = '';
        
        if (data.email) content += `Email: ${data.email}\n`;
        if (data.tele) content += `Tele: ${data.tele}\n`;
        if (data.logo) content += `LOGO: ${data.logo}\n`;
        if (data.names) content += `Names-Alias: ${data.names}\n`;
        if (data.NameBusiness) content += `Business: ${data.NameBusiness}\n`;
        if (data.description) content += `description of Business: ${data.description}\n`;

        return content;
    };

    const handleClose = () => setOpen(false);
    const handleClickOpen = () => setOpen(true);

    return (
        <>
            <div>
                <h3>Create QR Code Profile</h3> 
                <Button variant="contained" color="primary" onClick={handleClickOpen}>
                    Create QRCode Profile
                </Button>
                <Dialog open={open} onClose={handleClose}>
                    <DialogTitle>
                        QR Code
                    </DialogTitle>
                    <DialogContent>
                        <form onSubmit={insertQrCode}>
                            <label>Generate QR Code:</label>
                            <div style={{ marginTop: '20px' }}>
                                <QRCode value={constructQRContent()} />
                            </div>
                            <label> Name de Qr Code</label>
                            <input type="text" id="nameQrCode" value={nameQrCode} name="nameQrCode" onChange={(e)=>setNameQrCode(e.target.value)} />
                            <input type="submit" value="Send" />
                        </form>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleClose} color="primary">
                            Close
                        </Button>
                        <Button onClick={handleClose} color="primary" autoFocus>
                            Yes
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
            <br/>
        </>
    )
}
